package com.dsh.saintflorida;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {

    private static final String APP_ORIGIN = "https://appassets.androidplatform.net/";
    private static final String GAME_URL = APP_ORIGIN + "assets/index.html";

    private FrameLayout root;
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private TextView splash;
    private boolean pageReady = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        hideSystemUI();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 17, 23));

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 17, 23));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        configureWebView(webView);

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        splash = new TextView(this);
        splash.setText("圣佛罗里达\n\nAH-64D");
        splash.setTextColor(Color.rgb(127, 231, 255));
        splash.setTextSize(28);
        splash.setTypeface(Typeface.DEFAULT_BOLD);
        splash.setGravity(android.view.Gravity.CENTER);
        splash.setBackgroundColor(Color.rgb(11, 17, 23));
        root.addView(splash, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);
        loadGame();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setDefaultTextEncodingName("UTF-8");
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setGeolocationEnabled(false);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        view.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleUrl(url);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (!pageReady) {
                    pageReady = true;
                    hideSplash();
                    checkWebGL();
                }
            }

        });

        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return true;
            }
        });
    }

    private void loadGame() {
        pageReady = false;
        webView.loadUrl(GAME_URL);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!pageReady && splash != null) {
                showLoadError("加载超时。请确认 APK 资源完整，或更新 Android System WebView。");
            }
        }, 15000);
    }

    private boolean handleUrl(String url) {
        if (url == null) return true;
        if (url.startsWith(APP_ORIGIN) || url.startsWith("about:") ||
                url.startsWith("data:") || url.startsWith("blob:") ||
                url.startsWith("javascript:")) {
            return false;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {
        }
        return true;
    }

    private void checkWebGL() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){try{var c=document.createElement('canvas');" +
                "return !!(c.getContext('webgl')||c.getContext('experimental-webgl'));}catch(e){return false;}})()",
                value -> {
                    if (!"true".equals(value)) {
                        Toast.makeText(MainActivity.this,
                                "当前系统 WebView 未启用 WebGL，游戏可能无法显示。请更新 Android System WebView。",
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void hideSplash() {
        if (splash == null) return;
        final TextView s = splash;
        splash = null;
        s.animate().alpha(0f).setDuration(280).withEndAction(() -> {
            if (root != null) root.removeView(s);
        }).start();
    }

    private void showLoadError(String message) {
        runOnUiThread(() -> {
            pageReady = false;
            if (splash == null) {
                splash = new TextView(this);
                splash.setTextSize(20);
                splash.setTextColor(Color.rgb(255, 150, 130));
                splash.setGravity(android.view.Gravity.CENTER);
                splash.setBackgroundColor(Color.rgb(11, 17, 23));
                root.addView(splash, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
            }
            splash.setAlpha(1f);
            splash.setText("加载失败\n\n" + message + "\n\n点此重试");
            splash.setOnClickListener(v -> loadGame());
        });
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("退出游戏")
                .setMessage("进度保存在本机，确定退出？")
                .setNegativeButton("继续游戏", null)
                .setPositiveButton("退出", (dialog, which) -> finish())
                .show();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
