package com.dsh.saintflorida;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            hideSystemUI();

            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(11, 17, 23));
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(true);
            // 单文件游戏，放宽本地资源访问；没有外部网络页面
            try {
                s.setAllowFileAccessFromFileURLs(true);
                s.setAllowUniversalAccessFromFileURLs(true);
            } catch (Throwable ignored) {}
            s.setMediaPlaybackRequiresUserGesture(false);
            s.setSupportZoom(false);
            s.setBuiltInZoomControls(false);
            s.setDisplayZoomControls(false);
            s.setLoadWithOverviewMode(false);
            s.setUseWideViewPort(true);
            s.setDefaultTextEncodingName("UTF-8");
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            s.setSupportMultipleWindows(false);
            if (Build.VERSION.SDK_INT >= 21) {
                s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            }

            webView.setWebViewClient(new WebViewClient());
            webView.setWebChromeClient(new WebChromeClient());
            setContentView(webView);
            webView.loadUrl("file:///android_asset/index.html");
        } catch (Throwable t) {
            Log.e("SaintFlorida", "startup failed", t);
            showFatal(t);
        }
    }

    private void showFatal(Throwable t) {
        try {
            ScrollView sc = new ScrollView(this);
            TextView tv = new TextView(this);
            tv.setText("启动失败\n\n" + Log.getStackTraceString(t));
            tv.setTextColor(Color.rgb(255, 160, 140));
            tv.setTextSize(13);
            tv.setPadding(24, 24, 24, 24);
            tv.setBackgroundColor(Color.rgb(11, 17, 23));
            tv.setTextIsSelectable(true);
            sc.addView(tv);
            setContentView(sc);
        } catch (Throwable ignored) {}
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("退出游戏")
                .setMessage("进度保存在本机，确定退出？")
                .setNegativeButton("继续游戏", null)
                .setPositiveButton("退出", (d, w) -> finish())
                .show();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
