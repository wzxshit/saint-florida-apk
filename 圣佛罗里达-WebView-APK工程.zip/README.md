# 圣佛罗里达 · WebView APK

把单文件游戏 `圣佛罗里达2.3` 装进 Android 本地 WebView 壳：桌面图标启动、全屏横屏、离线运行，不再经过浏览器地址栏。

## 目录
```
app/src/main/assets/index.html      ← 游戏本体（v2.3）
app/src/main/java/.../MainActivity.java
app/src/main/AndroidManifest.xml
app/src/main/res/...                ← 图标、全屏主题
.github/workflows/android.yml       ← 云构建 APK
```

## 构建 APK（推荐：GitHub Actions，不需要电脑装 Android SDK）
1. 新建一个 GitHub 仓库，把本目录的全部文件上传（包括 `.github` 目录）。
2. 打开仓库的 **Actions** → **Build Saint Florida WebView APK** → **Run workflow**。
3. 等 3–5 分钟，进入这次运行，下载 **Artifacts → SaintFlorida-debug-apk**。
4. 解压得到 `app-debug.apk`，传到手机安装（允许“安装未知应用”）。

> 本机环境没有 Android SDK，所以这里只提供了可直接云构建的工程，不是已编译 APK。

## 本机已做的核验
- `MainActivity.java` 已用 **Android 34 android.jar + androidx.webkit 1.11.0** 编译通过（只有系统 API 弃用警告）。
- `AndroidManifest.xml`、`styles.xml`、`colors.xml`、`strings.xml` 全部 XML 解析通过。
- 游戏资源 `assets/index.html` 就是 **v2.3** 原文件，未改代码。
- Gradle 使用 AGP 8.5.2 + Gradle 8.7 + JDK 17。
- CI 使用 `WebViewAssetLoader` 从 `assets/` 提供页面，避免 `loadData` 的 1MB Binder 限制，同时给 localStorage 一个稳定的 https 源。

## 已设置
- 全屏沉浸式、隐藏状态栏/导航栏、常亮、横屏（sensorLandscape）。
- WebView：JS、DOM Storage、Database、硬件加速、媒体自动播放、混合内容兼容。
- 无文件系统访问；资源通过 `https://appassets.androidplatform.net/assets/` 提供。
- 保留 `INTERNET` 权限，只为游戏内“联机”使用；纯单机不需要网络。
- 返回键：网页可后退则后退，否则弹“退出游戏”确认。
- 启动页 / 加载失败重试 / WebGL 检测提示。
- 图标：直升机剪影。

## 安装后检查清单
- [ ] 启动不白屏，能看到“圣佛罗里达 / AH-64D”启动页后进主菜单
- [ ] 点“新游戏”，城市和车辆正常渲染（WebGL 正常）
- [ ] 触摸摇杆、按钮正常，声效在第一次点击后正常
- [ ] 存档/读档后进度还在（localStorage）
- [ ] 返回键弹退出确认
- [ ] 横屏旋转/全屏正常
- [ ] 去空军基地上直升机，炮手视角/武器正常

## 常见问题
- **安装被拦截**：允许文件管理器/浏览器“安装未知应用”；这是 debug 签名 APK。
- **白屏/模型不显示**：更新 **Android System WebView** 或 Chrome；部分旧机型 WebGL 被关。
- **清数据会丢存档**：设置里“清除数据”会清 localStorage；卸载也会。
- **联机**：需要同一局域网；`INTERNET` 已保留，`usesCleartextTraffic` 已允许 ws://。
- **要上架应用商店**：需要改成 release 签名并配置自己的 keystore，当前 workflow 产出的是可安装的 debug APK。

## 版本
- 游戏：v2.3
- App：versionName 2.3 / versionCode 23
- 包名：`com.dsh.saintflorida`
